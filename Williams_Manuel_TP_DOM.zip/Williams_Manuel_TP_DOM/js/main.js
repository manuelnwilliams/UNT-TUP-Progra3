
const listaCategorias = document.getElementById('lista-categorias');
const cargarCategorias = () => {
    categorias.forEach(categoria => {
        const li = document.createElement('li');
        li.textContent = categoria;
        listaCategorias.appendChild(li);
    });
};
cargarCategorias();

const contenedorProductos = document.getElementById('contenedor-productos');
const cargarProductos = () => {
    productos.forEach(producto => {
        const card = document.createElement('div');
        card.innerHTML = `
            <h3>${producto.nombre}</h3>
            <img src="${producto.imagen}" alt="${producto.nombre}">
            <p>${producto.descripcion}</p>
            <p>Precio: $${producto.precio.toFixed(2)}</p>
        `;
        contenedorProductos.appendChild(card);
    });
};
cargarProductos();